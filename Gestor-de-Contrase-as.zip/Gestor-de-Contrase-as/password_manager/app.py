from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import random
import csv
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

contrasenas = {
    "nombre_servicio_1": {"usuario": "usuario_1", "contrasena": "contrasena_1"},
    "nombre_servicio_2": {"usuario": "usuario_2", "contrasena": "contrasena_2"},
}

def generar_contrasena(longitud):
    caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&/()=?¿¡*+-1234567890"
    return ''.join(random.choice(caracteres) for _ in range(longitud))

def cargar_contrasenas():
    if os.path.exists('passwords.csv'):
        with open('passwords.csv', 'r') as archivo_csv:
            reader = csv.reader(archivo_csv)
            for row in reader:
                if len(row) == 2:  # Asegúrate de que la fila tiene exactamente dos elementos
                    contrasenas[row[0]] = row[1]

def guardar_contrasenas():
    with open('passwords.csv', 'w') as archivo_csv:
        writer = csv.writer(archivo_csv)
        for nombre, contrasena in contrasenas.items():
            writer.writerow([nombre, contrasena])

@app.route('/')
def index():
    return render_template('index.html', contrasenas=contrasenas)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        usuario = request.form.get('usuario')  # Nuevo campo de usuario
        tipo_contrasena = 'aleatoria'  # Cambio aquí
        
        if not nombre:
            flash('Por favor ingrese un nombre de servicio.')
            return redirect(url_for('add'))
        
        if tipo_contrasena == 'aleatoria':
            longitud = request.form.get('longitud')
            if not longitud or not longitud.isdigit() or int(longitud) < 1:
                flash('Por favor ingrese una longitud válida para la contraseña.')
                return redirect(url_for('add'))
            longitud = int(longitud)
            contrasena = generar_contrasena(longitud)
        else:
            flash('Incorrecto.')
            return redirect(url_for('add'))
        
        contrasenas[nombre] = {'usuario': usuario, 'contrasena': contrasena}  # Modificado para almacenar el usuario también
        guardar_contrasenas()
        flash('Contraseña agregada correctamente.')
        return redirect(url_for('index'))
    
    return render_template('add.html')

@app.route('/edit/<nombre>', methods=['GET', 'POST'])
def edit(nombre):
    if request.method == 'POST':
        nueva_contrasena = request.form['contrasena']
        contrasenas[nombre] = nueva_contrasena
        guardar_contrasenas()
        flash('Contraseña actualizada correctamente.')
        return redirect(url_for('index'))
    return render_template('edit.html', nombre=nombre, contrasena=contrasenas[nombre])

@app.route('/delete/<nombre>')
def delete(nombre):
    if nombre in contrasenas:
        del contrasenas[nombre]
        guardar_contrasenas()
        flash('Producto eliminado exitosamente.')
    return redirect(url_for('index'))

@app.route('/exportar')
def exportar():
    guardar_contrasenas()
    return send_file('passwords.csv', as_attachment=True)

if __name__ == '__main__':
    cargar_contrasenas()
    app.run(debug=True)
