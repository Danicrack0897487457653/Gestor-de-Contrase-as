function validarFormulario() {
    var opcion = document.getElementById('opcion').value;
    var longitud = document.getElementById('longitud').value;
    var contrasena = document.getElementById('contrasena').value;
    var btnSubmit = document.getElementById('btn-submit');
    
    if (opcion === 'manual' && contrasena.trim() === '') {
        alert('Por favor ingrese una contraseña.');
        return;
    }
    
    if (opcion === 'aleatoria' && (isNaN(longitud) || longitud < 1)) {
        alert('Por favor ingrese una longitud válida para la contraseña.');
        return;
    }
    
    btnSubmit.disabled = false;
    document.getElementById('add-form').submit();
}

