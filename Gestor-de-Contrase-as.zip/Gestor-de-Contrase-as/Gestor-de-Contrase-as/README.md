# Gestor-de-Contrasenas

Uso:
Para agregar una nueva contraseña, haz clic en "Agregar Nueva Contraseña" en la página principal, completa el formulario y haz clic en "Agregar".
Para editar una contraseña existente, haz clic en "Editar" junto a la contraseña que deseas modificar en la página principal, realiza los cambios necesarios y haz clic en "Guardar".
Para eliminar una contraseña, haz clic en "Eliminar" junto a la contraseña que deseas eliminar en la página principal.
Puedes exportar todas las contraseñas a un archivo CSV haciendo clic en "Descargar Contraseñas" en la página principal.

Este es un proyecto muy basico pensado para guardar contraseñas y permitir que se editen o borren y guardarlo
